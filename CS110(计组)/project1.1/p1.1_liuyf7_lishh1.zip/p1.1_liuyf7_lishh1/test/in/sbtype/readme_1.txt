branch_here: addi x5, x6, 20
lui x5, 8
slli x6, x6, 11
srli x6, x6, 11
andi x8, x8, -15
beq x8, x0, branch_here


