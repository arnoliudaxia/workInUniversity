#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "compression.h"
#include "utils.h"
#ifdef  _WIN32
#pragma warning(disable : 4996)
#endif
command phraseLine(const char* operation)
{
    /*serwqewq*/
    int i, j, flag, sum;
/*12312*/
    command nowcmd;
/*12312*/
    flag = 0;
/*12312*/
    sum = 0;
/*12312*/
    memset(nowcmd.rd, '\0', 6 * sizeof(char));
/*12312*/
    memset(nowcmd.rs1, '\0', 6 * sizeof(char));
/*12312*/
    memset(nowcmd.rs2, '\0', 6 * sizeof(char));
/*12312*/
    substring(operation, 25, 7, nowcmd.opcode);
/*12312*/
    /*R-format*/
    if (strcmp(nowcmd.opcode, "0110011") == 0)
    {
        substring(operation, 0, 7, nowcmd.funct7);
/*12312*/
        substring(operation, 7, 5, nowcmd.rs2);
/*12312*/
        substring(operation, 12, 5, nowcmd.rs1);
/*12312*/
        substring(operation, 17, 3, nowcmd.funct3);
/*12312*/
        substring(operation, 20, 5, nowcmd.rd);
/*12312*/
    }
    /*I-format*/
    if (strcmp(nowcmd.opcode, "1100111") == 0 || strcmp(nowcmd.opcode, "0010011") == 0 || strcmp(nowcmd.opcode, "0000011") == 0)
    {
        substring(operation, 0, 12, nowcmd.imm);
/*12312*/
        substring(operation, 12, 5, nowcmd.rs1);
/*12312*/
        substring(operation, 17, 3, nowcmd.funct3);
/*12312*/
        substring(operation, 20, 5, nowcmd.rd);
/*12312*/
        substring(operation, 0, 7, nowcmd.funct7);
/*12312*/
        substring(operation, 10, 2, nowcmd.temp);
/*12312*/
        for (i = 0; (size_t)i < strlen(nowcmd.imm); i++)
        {
            if (nowcmd.imm[i] != '0')break;
/*12312*/
        }
        if (i == 0)
        {
            for (j = 0; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] == '0'){flag = j;break;}
            }
            /*12312*/
            for (; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] != '0')sum++;
/*12312*/
            }
            if ((size_t)(flag + sum) == strlen(nowcmd.imm) && flag != 0)nowcmd.immzip = 14 - flag;
/*12312*/
            else if (flag == 0)nowcmd.immzip = 0;
/*12312*/
            else nowcmd.immzip = 13 - flag;
/*12312*/
        }
        else nowcmd.immzip = 13 - i;
/*12312*/
        if (strcmp(nowcmd.funct7, "0100000") == 0) nowcmd.immzip = 0;
/*12312*/
    }
    /*S-format*/
    if (strcmp(nowcmd.opcode, "0100011") == 0)
    {
        substring(operation, 0, 7, nowcmd.imm);
/*12312*/
        substring(operation, 7, 5, nowcmd.rs2);
/*12312*/
        substring(operation, 12, 5, nowcmd.rs1);
/*12312*/
        substring(operation, 17, 3, nowcmd.funct3);
/*12312*/
        substring(operation, 20, 5, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 7, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 23, 2, nowcmd.temp);
/*12312*/
        for (i = 0; (size_t)i < strlen(nowcmd.imm); i++)
        {
            if (nowcmd.imm[i] != '0')break;
/*12312*/
        }
        if (i == 0)
        {
            /*12312*/
            for (j = 0; (size_t)j < strlen(nowcmd.imm); j++)
            {
                /*12312*/
                if (nowcmd.imm[j] == '0'){flag = j;break;}
            }
            for (; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] != '0')sum++;
/*12312*/
            }
            if ((size_t)(flag + sum) == strlen(nowcmd.imm) && flag != 0)nowcmd.immzip = 14 - flag;
/*12312*/
            else if (flag == 0)nowcmd.immzip = 0;
/*12312*/
            else nowcmd.immzip = 13 - flag;
/*12312*/
        }
        else nowcmd.immzip = 13 - i;
/*12312*/
    }
    /*SB-format*/
    if (strcmp(nowcmd.opcode, "1100011") == 0)
    {
        int i;
/*12312*/
        substring(operation, 0, 1, nowcmd.imm);
/*12312*/
        substring(operation, 24, 1, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 1, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 1, 6, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 2, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 20, 4, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 8, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 7, 5, nowcmd.rs2);
/*12312*/
        substring(operation, 12, 5, nowcmd.rs1);
/*12312*/
        substring(operation, 17, 3, nowcmd.funct3);
/*12312*/
        for (i = 0; (size_t)i < strlen(nowcmd.imm); i++)
        {
            if (nowcmd.imm[i] != '0')break;
/*12312*/
        }
        if (i == 0)
        {
            for (j = 0; (size_t)j < strlen(nowcmd.imm); j++)
            {
                /*12312*/
                if (nowcmd.imm[j] == '0'){flag = j;break;}
            }
            for (; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] != '0')sum++;
/*12312*/
            }
            if ((size_t)(flag + sum) == strlen(nowcmd.imm) && flag != 0)nowcmd.immzip = 14 - flag;
/*12312*/
            else if (flag == 0)nowcmd.immzip = 0;
/*12312*/
            else nowcmd.immzip = 13 - flag;
/*12312*/
        }
        else nowcmd.immzip = 13 - i;
/*12312*/
    }
    /*U-format*/
    if (strcmp(nowcmd.opcode, "0110111") == 0)
    {
        substring(operation, 0, 20, nowcmd.imm);
/*12312*/
        substring(operation, 20, 5, nowcmd.rd);
/*12312*/
        for (i = 0; (size_t)i < strlen(nowcmd.imm); i++)
        {
            if (nowcmd.imm[i] != '0')break;
/*12312*/
        }
        if (i == 0)
        {
            for (j = 0; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] == '0'){flag = j;break;}/*12312*/
            }/*12312*/
            for (; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] != '0')sum++;
/*12312*/
            }
            if ((size_t)(flag + sum) == strlen(nowcmd.imm) && flag != 0)nowcmd.immzip = 22 - flag;
/*12312*/
            else if (flag == 0)nowcmd.immzip = 0;
/*12312*/
            else nowcmd.immzip = 21 - flag;
/*12312*/
        }
        else nowcmd.immzip = 21 - i;
/*12312*/
    }
    /*J-format*/
    if (strcmp(nowcmd.opcode, "1101111") == 0)
    {
        substring(operation, 0, 1, nowcmd.imm);
/*12312*/
        substring(operation, 12, 8, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 1, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 11, 1, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 9, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 1, 10, nowcmd.temp);
/*12312*/
        strcpy(nowcmd.imm + 10, nowcmd.temp);
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        substring(operation, 20, 5, nowcmd.rd);
/*12312*/
        substring(nowcmd.imm, 0, 8, nowcmd.temp);
/*12312*/
        for (i = 0; (size_t)i < strlen(nowcmd.imm); i++)
        {
            if (nowcmd.imm[i] != '0')break;
/*12312*/
        }
        if (i == 0)
        {
            for (j = 0; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] == '0'){flag = j;break;}
            }/*12312*/
            for (; (size_t)j < strlen(nowcmd.imm); j++)
            {
                if (nowcmd.imm[j] != '0')sum++;
/*12312*/
            }
            if ((size_t)(flag + sum) == strlen(nowcmd.imm) && flag != 0)nowcmd.immzip = 22 - flag;
/*12312*/
            else if (flag == 0)nowcmd.immzip = 0;
/*12312*/
            else nowcmd.immzip = 21 - flag;
/*12312*/
        }
        else nowcmd.immzip = 21 - i;
/*12312*/
    }
    return nowcmd;
/*12312*/
}
void compressLine(const char* operation, char* processed)
{
    command nowcmd;
/*12312*/
    int compressed;
/*12312*/
    char compressedCom[17];
/*12312*/
    char rdc[4], rs1c[4], rs2c[4];
/*12312*/
    int compressibleRes;
/*12312*/
    printf("%c\n", operation[0]);
/*12312*/
    assert(strlen(operation) == 32);
/*12312*/
    printf("%s\n", operation);
/*12312*/
    nowcmd = phraseLine(operation);
/*12312*/
    compressed = 0;
/*12312*/
    rdc[0] = '\0';
/*12312*/
    rs1c[0] = '\0';
/*12312*/
    rs2c[0] = '\0';
/*12312*/
    compressibleRes = 1;
/*12312*/
    compressibleRes &= smallRes(nowcmd.rd, rdc);
/*12312*/
    compressibleRes &= smallRes(nowcmd.rs1, rs1c);
/*12312*/
    compressibleRes &= smallRes(nowcmd.rs2, rs2c);
/*12312*/
    /* add rd, rd, rs2	R	c.add	CR	rdâ‰ x0; rs2â‰ x0 */
    /* now you need to check if the command is simplyable,
    if yes, return the compressed 16-bit command (in char)
    other wise just return the argument
     */
     /* the following is an example for add rd, rd, rs2 */
     /*CR compress*/
     /*R*/
    if (strcmp(nowcmd.opcode, "0110011") == 0)
    {
        if (strcmp(nowcmd.funct7, "0000000") == 0 && strcmp(nowcmd.funct3, "000") == 0)
        {
            /*add*/
            if (strcmp(nowcmd.rd, nowcmd.rs1) == 0 && strcmp(nowcmd.rd, "00000") != 0 && strcmp(nowcmd.rs2, "00000") != 0)
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "1001");
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rd);
/*12312*/
                strcpy(compressedCom + 9, nowcmd.rs2);
/*12312*/
                strcpy(compressedCom + 14, "10");
/*12312*/
            }
            /*move*/
            if (strcmp(nowcmd.rs1, "00000") == 0 && strcmp(nowcmd.rd, "00000") != 0 && strcmp(nowcmd.rs2, "00000") != 0)
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "1000");
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rd);
/*12312*/
                strcpy(compressedCom + 9, nowcmd.rs2);
/*12312*/
                strcpy(compressedCom + 14, "10");
/*12312*/
            }
        }
        /*and*/
        if (strcmp(nowcmd.funct3, "111") == 0 && strcmp(nowcmd.funct7, "0000000") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && compressibleRes && checkx0(&nowcmd, 1, 0, 1))
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100011");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            strcpy(compressedCom + 9, "11");
/*12312*/
            strcpy(compressedCom + 11, rs2c);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
        /*or*/
        if (strcmp(nowcmd.funct3, "110") == 0 && strcmp(nowcmd.funct7, "0000000") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && compressibleRes && checkx0(&nowcmd, 1, 0, 1))
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100011");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            strcpy(compressedCom + 9, "10");
/*12312*/
            strcpy(compressedCom + 11, rs2c);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
        /*xor*/
        if (strcmp(nowcmd.funct3, "100") == 0 && strcmp(nowcmd.funct7, "0000000") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && compressibleRes && checkx0(&nowcmd, 1, 0, 1))
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100011");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            strcpy(compressedCom + 9, "01");
/*12312*/
            strcpy(compressedCom + 11, rs2c);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
        /*sub*/
        if (strcmp(nowcmd.funct3, "000") == 0 && strcmp(nowcmd.funct7, "0100000") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && compressibleRes && checkx0(&nowcmd, 1, 0, 1))
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100011");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            strcpy(compressedCom + 9, "00");
/*12312*/
            strcpy(compressedCom + 11, rs2c);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
    }
    /*I*/
    if (strcmp(nowcmd.opcode, "1100111") == 0 || strcmp(nowcmd.opcode, "0010011") == 0 || strcmp(nowcmd.opcode, "0000011") == 0)
    {
        /*jalr*/
        if (strcmp(nowcmd.funct3, "000") == 0 && strcmp(nowcmd.opcode, "1100111") == 0)
        {
            /*jr*/
            if (strcmp(nowcmd.rd, "00000") == 0 && strcmp(nowcmd.rs1, "00000") != 0 && strcmp(nowcmd.imm, "000000000000") == 0)
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "1000");
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rs1);
/*12312*/
                strcpy(compressedCom + 9, "00000");
/*12312*/
                strcpy(compressedCom + 14, "10");
/*12312*/
            }
            /*jalr*/
            if (strcmp(nowcmd.rd, "00001") == 0 && strcmp(nowcmd.rs1, "00000") != 0 && strcmp(nowcmd.imm, "000000000000") == 0)
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "1001");
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rs1);
/*12312*/
                strcpy(compressedCom + 9, "00000");
/*12312*/
                strcpy(compressedCom + 14, "10");
/*12312*/
            }
        }
        /*addi*/
        if (strcmp(nowcmd.funct3, "000") == 0 && strcmp(nowcmd.opcode, "0010011") == 0 && nowcmd.immzip <= 6)
        {
            /*li*/
            if (strcmp(nowcmd.rd, "00000") != 0 && strcmp(nowcmd.rs1, "00000") == 0)
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "010");
/*12312*/
                compressedCom[3] = nowcmd.imm[6];
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rd);
/*12312*/
                substring(nowcmd.imm, 7, 5, nowcmd.temp);
/*12312*/
                strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
                strcpy(compressedCom + 14, "01");
/*12312*/
            }
            /*addi*/
            if (strcmp(nowcmd.rd, "00000") != 0 && strcmp(nowcmd.rs1, nowcmd.rd) == 0 && strcmp(nowcmd.imm, "000000000000") != 0 && nowcmd.immzip <= 6)
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "000");
/*12312*/
                compressedCom[3] = nowcmd.imm[6];
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rd);
/*12312*/
                substring(nowcmd.imm, 7, 5, nowcmd.temp);
/*12312*/
                strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
                strcpy(compressedCom + 14, "01");
/*12312*/
            }
        }
        /*slli*/
        if (strcmp(nowcmd.opcode, "0010011") == 0 && strcmp(nowcmd.funct3, "001") == 0 && nowcmd.immzip <= 6)
        {
            if (strcmp(nowcmd.rd, "00000") != 0 && strcmp(nowcmd.rs1, nowcmd.rd) == 0 && nowcmd.imm[6] == '0')
            {
                compressed = 1;
/*12312*/
                strcpy(compressedCom, "000");
/*12312*/
                compressedCom[3] = nowcmd.imm[6];
/*12312*/
                strcpy(compressedCom + 4, nowcmd.rd);
/*12312*/
                substring(nowcmd.imm, 7, 5, nowcmd.temp);
/*12312*/
                strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
                strcpy(compressedCom + 14, "10");
/*12312*/
            }
        }
        /*lw*/
        if (compressibleRes && checkx0(&nowcmd, 1, 1, 0) && strcmp(nowcmd.opcode, "0000011") == 0 && strcmp(nowcmd.funct3, "010") == 0 && nowcmd.immzip <= 8 && strcmp(nowcmd.temp, "00") == 0 && nowcmd.imm[0] != '1')
        {
            compressed = 1;
/*12312*/
            memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
            strcpy(compressedCom, "010");
/*12312*/
            substring(nowcmd.imm, 6, 3, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 3, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 6, rs1c);
/*12312*/
            compressedCom[9] = nowcmd.imm[9];
/*12312*/
            compressedCom[10] = nowcmd.imm[5];
/*12312*/
            strcpy(compressedCom + 11, rdc);
/*12312*/
            strcpy(compressedCom + 14, "00");
/*12312*/
        }
        /*srli*/
        if (strcmp(nowcmd.opcode, "0010011") == 0 && strcmp(nowcmd.funct3, "101") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && nowcmd.imm[6] == '0' && strcmp(nowcmd.funct7, "0000000") == 0 && compressibleRes && checkx0(&nowcmd, 1, 0, 0) && nowcmd.immzip <= 6)
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100");
/*12312*/
            compressedCom[3] = nowcmd.imm[6];
/*12312*/
            strcpy(compressedCom + 4, "00");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            substring(nowcmd.imm, 7, 5, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
        /*srai*/
        if (compressibleRes && checkx0(&nowcmd, 1, 0, 0) && strcmp(nowcmd.opcode, "0010011") == 0 && strcmp(nowcmd.funct3, "101") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && nowcmd.imm[6] == '0' && strcmp(nowcmd.funct7, "0100000") == 0 && nowcmd.immzip <= 6)
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100");
/*12312*/
            compressedCom[3] = nowcmd.imm[6];
/*12312*/
            strcpy(compressedCom + 4, "01");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            substring(nowcmd.imm, 7, 5, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
        /*andi*/
        if (compressibleRes && checkx0(&nowcmd, 1, 0, 0) && strcmp(nowcmd.opcode, "0010011") == 0 && strcmp(nowcmd.funct3, "111") == 0 && strcmp(nowcmd.rd, nowcmd.rs1) == 0 && nowcmd.immzip <= 6 && compressibleRes)
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "100");
/*12312*/
            compressedCom[3] = nowcmd.imm[6];
/*12312*/
            strcpy(compressedCom + 4, "10");
/*12312*/
            strcpy(compressedCom + 6, rdc);
/*12312*/
            substring(nowcmd.imm, 7, 5, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
    }
    /*U*/
    /*lui*/
    if (strcmp(nowcmd.opcode, "0110111") == 0 && nowcmd.immzip <= 6 && strcmp(nowcmd.rd, "00000") != 0 && strcmp(nowcmd.rd, "00010") != 0 && strcmp(nowcmd.imm, "00000000000000000000") != 0)
    {
        compressed = 1;
/*12312*/
        strcpy(compressedCom, "011");
/*12312*/
        compressedCom[3] = nowcmd.imm[14];
/*12312*/
        strcpy(compressedCom + 4, nowcmd.rd);
/*12312*/
        substring(nowcmd.imm, 15, 5, nowcmd.temp);
/*12312*/
        strcpy(compressedCom + 9, nowcmd.temp);
/*12312*/
        strcpy(compressedCom + 14, "01");
/*12312*/
    }
    /*S*/
    if (strcmp(nowcmd.opcode, "0100011") == 0 && strcmp(nowcmd.funct3, "010") == 0 && nowcmd.immzip <= 8 && strcmp(nowcmd.temp, "00") == 0 && compressibleRes && checkx0(&nowcmd, 0, 1, 0) && nowcmd.imm[0] != '1')
    {
        compressed = 1;
/*12312*/
        memset(nowcmd.temp, 0, sizeof(nowcmd.temp));
/*12312*/
        strcpy(compressedCom, "110");
/*12312*/
        substring(nowcmd.imm, 6, 3, nowcmd.temp);
/*12312*/
        strcpy(compressedCom + 3, nowcmd.temp);
/*12312*/
        strcpy(compressedCom + 6, rs1c);
/*12312*/
        compressedCom[9] = nowcmd.imm[9];
/*12312*/
        compressedCom[10] = nowcmd.imm[5];
/*12312*/
        strcpy(compressedCom + 11, rs2c);
/*12312*/
        strcpy(compressedCom + 14, "00");
/*12312*/
    }
    /*SB*/
    if (strcmp(nowcmd.opcode, "1100011") == 0)
    {
        /*beq*/
        if (strcmp(nowcmd.funct3, "000") == 0 && strcmp(nowcmd.rs2, "00000") == 0 && compressibleRes && checkx0(&nowcmd, 0, 1, 0) && nowcmd.immzip <= 8)
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "110");
/*12312*/
            compressedCom[3] = nowcmd.imm[4];
/*12312*/
            compressedCom[4] = nowcmd.imm[8];
/*12312*/
            compressedCom[5] = nowcmd.imm[9];
/*12312*/
            strcpy(compressedCom + 6, rs1c);
/*12312*/
            compressedCom[9] = nowcmd.imm[5];
/*12312*/
            compressedCom[10] = nowcmd.imm[6];
/*12312*/
            compressedCom[11] = nowcmd.imm[10];
/*12312*/
            compressedCom[12] = nowcmd.imm[11];
/*12312*/
            compressedCom[13] = nowcmd.imm[7];
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
        /*bne*/
        if (strcmp(nowcmd.funct3, "001") == 0 && strcmp(nowcmd.rs2, "00000") == 0 && compressibleRes && checkx0(&nowcmd, 0, 1, 0) && nowcmd.immzip <= 8)
        {
            compressed = 1;
/*12312*/
            strcpy(compressedCom, "111");
/*12312*/
            compressedCom[3] = nowcmd.imm[4];
/*12312*/
            compressedCom[4] = nowcmd.imm[8];
/*12312*/
            compressedCom[5] = nowcmd.imm[9];
/*12312*/
            strcpy(compressedCom + 6, rs1c);
/*12312*/
            compressedCom[9] = nowcmd.imm[5];
/*12312*/
            compressedCom[10] = nowcmd.imm[6];
/*12312*/
            compressedCom[11] = nowcmd.imm[10];
/*12312*/
            compressedCom[12] = nowcmd.imm[11];
/*12312*/
            compressedCom[13] = nowcmd.imm[7];
/*12312*/
            strcpy(compressedCom + 14, "01");
/*12312*/
        }
    }
    /*J*/
    /*j*/
    if (strcmp(nowcmd.opcode, "1101111") == 0 && strcmp(nowcmd.rd, "00000") == 0)
    {
        compressed = 1;
/*12312*/
        strcpy(compressedCom, "101");
/*12312*/
        compressedCom[3] = nowcmd.imm[9];
/*12312*/
        compressedCom[4] = nowcmd.imm[16];
/*12312*/
        compressedCom[5] = nowcmd.imm[11];
/*12312*/
        compressedCom[6] = nowcmd.imm[12];
/*12312*/
        compressedCom[7] = nowcmd.imm[10];
/*12312*/
        compressedCom[8] = nowcmd.imm[14];
/*12312*/
        compressedCom[9] = nowcmd.imm[13];
/*12312*/
        compressedCom[10] = nowcmd.imm[17];
/*12312*/
        compressedCom[11] = nowcmd.imm[18];
/*12312*/
        compressedCom[12] = nowcmd.imm[19];
/*12312*/
        compressedCom[13] = nowcmd.imm[15];
/*12312*/
        strcpy(compressedCom + 14, "01");
/*12312*/
    }
    /*jal*/
    if (strcmp(nowcmd.opcode, "1101111") == 0 && strcmp(nowcmd.rd, "00001") == 0)
    {
        compressed = 1;
/*12312*/
        strcpy(compressedCom, "001");
/*12312*/
        compressedCom[3] = nowcmd.imm[9];
/*12312*/
        compressedCom[4] = nowcmd.imm[16];
/*12312*/
        compressedCom[5] = nowcmd.imm[11];
/*12312*/
        compressedCom[6] = nowcmd.imm[12];
/*12312*/
        compressedCom[7] = nowcmd.imm[10];
/*12312*/
        compressedCom[8] = nowcmd.imm[14];
/*12312*/
        compressedCom[9] = nowcmd.imm[13];
/*12312*/
        compressedCom[10] = nowcmd.imm[17];
/*12312*/
        compressedCom[11] = nowcmd.imm[18];
/*12312*/
        compressedCom[12] = nowcmd.imm[19];
/*12312*/
        compressedCom[13] = nowcmd.imm[15];
/*12312*/
        strcpy(compressedCom + 14, "01");
/*12312*/
    }
    /* note!!! do not copy below for each type, you can just add condition into if structure */
    if (!compressed)
        strcpy(processed, operation);
/*12312*/
    else
        strcpy(processed, compressedCom);
/*12312*/
}
void increaseStringByOne(char* input)
{
    int i;
/*12312*/
    int length = strlen(input);
/*12312*/
    for (i = length - 1; i >= 0; i--)
    {
        if (input[i] == '0')
        {
            input[i] = '1';
/*12312*/
            break;
/*12312*/
        }
        input[i] = '0';
/*12312*/
    }
}
void decreaseStringByOne(char* input)
{
    int i;
/*12312*/
    int length = strlen(input);
/*12312*/
    for (i = length - 1; i >= 0; i--)
    {
        if (input[i] == '1')
        {
            input[i] = '0';
/*12312*/
            break;
/*12312*/
        }
        input[i] = '1';
/*12312*/
    }
}
void decreaseStringByTwo(char* input)
{
    if (input[0] == '0')
    {
        decreaseStringByOne(input);
/*12312*/
        decreaseStringByOne(input);
/*12312*/
    }
    else
    {
        increaseStringByOne(input);
/*12312*/
        increaseStringByOne(input);
/*12312*/
    }
}
void compressfile(FILE* fpin, FILE* fpout)
{
    int line, i, originalOffset, j;
/*12312*/
    char commands[255][34];
/*12312*/
    int commandsLength[255];
/*12312*/
    char buff[34], compressedLine[33];
/*12312*/
    line = 0;
/*12312*/
    while (fgets(buff, 36, fpin) && buff[0] != '\n' && strlen(buff) > 30)
    {
        if (buff[32] == '\n' || buff[32] == '\t' || 1)
        {
            buff[32] = '\0';
/*12312*/
        }
        compressLine(buff, compressedLine);
/*12312*/
        strcpy(commands[line], compressedLine);
/*12312*/
        commandsLength[line] = strlen(compressedLine);
/*12312*/
        line++;
/*12312*/
    }
    for (i = 0;i < line;i++)
    {
        char fixAddLine[34];
/*12312*/
        char opcode[3], funct3[4], offset[13];
/*12312*/
        int check;
/*12312*/
        strcpy(fixAddLine, commands[i]);
/*12312*/
        if (strlen(fixAddLine) == 16)
        {
            /* it indicates that it's a compressed command*/
            substring(fixAddLine, 0, 3, funct3);
/*12312*/
            substring(fixAddLine, 14, 2, opcode);
/*12312*/
            if (strcmp(opcode, "01") == 0 && (strcmp(funct3, "110") == 0 || strcmp(funct3, "111") == 0))
            {
                offset[8] = fixAddLine[3];
/*12312*/
                offset[4] = fixAddLine[4];
/*12312*/
                offset[3] = fixAddLine[5];
/*12312*/
                offset[7] = fixAddLine[16 - 7];
/*12312*/
                offset[6] = fixAddLine[16 - 6];
/*12312*/
                offset[2] = fixAddLine[16 - 5];
/*12312*/
                offset[1] = fixAddLine[12];
/*12312*/
                offset[5] = fixAddLine[13];
/*12312*/
                offset[0] = '0';
/*12312*/
                offset[9] = '\0';
/*12312*/
                /* ==fixtaskBegin====*/
                strrev(offset);
/*12312*/
                originalOffset = bintodec(offset);
/*12312*/
                if (offset[0] == '1')
                    originalOffset -= 512;
/*12312*/
                if (originalOffset < 0)
                {
                    for (j = 1; j <= abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                else
                {
                    for (j = 0; j < abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                strrev(offset);
/*12312*/
                fixAddLine[3] = offset[8];
/*12312*/
                fixAddLine[4] = offset[4];
/*12312*/
                fixAddLine[5] = offset[3];
/*12312*/
                fixAddLine[16 - 7] = offset[7];
/*12312*/
                fixAddLine[16 - 6] = offset[6];
/*12312*/
                fixAddLine[16 - 5] = offset[2];
/*12312*/
                fixAddLine[12] = offset[1];
/*12312*/
                fixAddLine[13] = offset[5];
/*12312*/
                /* == fixtaskEnd====*/
            }
            else if (strcmp(opcode, "01") == 0 && (strcmp(funct3, "101") == 0 || strcmp(funct3, "001") == 0))
            {
                offset[11] = fixAddLine[3];
/*12312*/
                offset[4] = fixAddLine[4];
/*12312*/
                offset[9] = fixAddLine[5];
/*12312*/
                offset[8] = fixAddLine[6];
/*12312*/
                offset[10] = fixAddLine[7];
/*12312*/
                offset[6] = fixAddLine[8];
/*12312*/
                offset[7] = fixAddLine[9];
/*12312*/
                offset[3] = fixAddLine[10];
/*12312*/
                offset[2] = fixAddLine[11];
/*12312*/
                offset[1] = fixAddLine[12];
/*12312*/
                offset[5] = fixAddLine[13];
/*12312*/
                offset[12] = '\0';
/*12312*/
                offset[0] = '0';
/*12312*/
                strrev(offset);
/*12312*/
                originalOffset = bintodec(offset);
/*12312*/
                if (offset[0] == '1')
                    originalOffset -= 4096;
/*12312*/
                if (originalOffset < 0)
                {
                    for (j = 1; j <= abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                else
                {
                    for (j = 0; j < abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                strrev(offset);
/*12312*/
                fixAddLine[3] = offset[11];
/*12312*/
                fixAddLine[4] = offset[4];
/*12312*/
                fixAddLine[5] = offset[9];
/*12312*/
                fixAddLine[6] = offset[8];
/*12312*/
                fixAddLine[7] = offset[10];
/*12312*/
                fixAddLine[8] = offset[6];
/*12312*/
                fixAddLine[9] = offset[7];
/*12312*/
                fixAddLine[10] = offset[3];
/*12312*/
                fixAddLine[11] = offset[2];
/*12312*/
                fixAddLine[12] = offset[1];
/*12312*/
                fixAddLine[13] = offset[5];
/*12312*/
            }
        }
        else if (strlen(fixAddLine) == 32)
        {
            command again;
/*12312*/
            again = phraseLine(fixAddLine);
/*12312*/
            if (strcmp(again.opcode, "1100011") == 0)
            {
                /*Btype*/
                strrev(again.imm);
/*12312*/
                substring(again.imm, 0, 12, offset + 1);
/*12312*/
                offset[0] = '0';
/*12312*/
                strrev(offset);
/*12312*/
                originalOffset = bintodec(offset);
/*12312*/
                if (offset[0] == '1')
                    originalOffset -= 8192;
/*12312*/
                if (originalOffset < 0)
                {
                    for (j = 1; j <= abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                else
                {
                    for (j = 0; j < abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                strrev(offset);
/*12312*/
                fixAddLine[0] = offset[12];
/*12312*/
                fixAddLine[1] = offset[10];
/*12312*/
                fixAddLine[2] = offset[9];
/*12312*/
                fixAddLine[3] = offset[8];
/*12312*/
                fixAddLine[4] = offset[7];
/*12312*/
                fixAddLine[5] = offset[6];
/*12312*/
                fixAddLine[6] = offset[5];
/*12312*/
                fixAddLine[20] = offset[4];
/*12312*/
                fixAddLine[21] = offset[3];
/*12312*/
                fixAddLine[22] = offset[2];
/*12312*/
                fixAddLine[23] = offset[1];
/*12312*/
            }
            if (strcmp(again.opcode, "1101111") == 0)
            {
                /* 32-bit jal adress fix*/
                strrev(again.imm);
/*12312*/
                substring(again.imm, 0, 10, offset + 1);
/*12312*/
                offset[0] = '0';
/*12312*/
                offset[11] = '\0';
/*12312*/
                strrev(offset);
/*12312*/
                originalOffset = bintodec(offset);
/*12312*/
                if (offset[0] == '1')
                    originalOffset -= 2048;
/*12312*/
                if (originalOffset < 0)
                {
                    for (j = 1; j <= abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                else
                {
                    for (j = 0; j < abs(originalOffset) / 4; j++)
                    {
                        check = originalOffset > 0 ? i + j : i - j;
/*12312*/
                        if (commandsLength[check] < 30)
                        {
                            decreaseStringByTwo(offset);
/*12312*/
                        }
                    }
                }
                for (j = 1;j < 11;j++)
                {
                    fixAddLine[j] = offset[j - 1];
/*12312*/
                }
            }
        }
        fputs(fixAddLine, fpout);
/*12312*/
        fputc('\n', fpout);
/*12312*/
    }
}
