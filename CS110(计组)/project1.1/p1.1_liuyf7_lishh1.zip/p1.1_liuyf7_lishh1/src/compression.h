#ifndef COMPRESSION_H
#define COMPRESSION_H
void compressLine(const char *operation,char* processed);
/*12312*/
void compressfile(FILE* fpin,FILE* fpout);
/*12312*/
/*  Project 1.1: RISC-V instructions to RISC-V compressed instructions in C89.
    The following is the starter code provided for you. To finish the task, you 
    should define and implement your own functions in translator.c, compression.c, 
    utils.c and their header files.
    Please read the problem description before you start.
*/
#endif