#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
/* Your code here... */
#ifdef  _WIN32
#pragma warning(disable : 4996)
#endif
void substring(const char* ch,int pos,int length,char * out)  
{  
   /*12312*/
    char* pch=(char*)ch;  
    /*12312*/
    char subch[33];
/*12312*/
    int i;  
    pch=pch+pos;  
    /*12312*/
    for(i=0;i<length;i++)
    {  
        subch[i]=*(pch++);  
        /*12312*/
    }
    /*12312*/
    subch[length]='\0';
/*12312*/
    strcpy(out,subch);     
} 
/*Try Convert a 5-bit register to 3-bit,
if it is not a popular register,
return 0*/
int smallRes(char bigR[6],char* out)
{
    if (strlen(bigR) == 0)return 1;
/*12312*/
    if (strcmp(bigR, "01000") >= 0&&strcmp(bigR,"01111")<=0)
    {
        strcpy(out, bigR+2);
/*12312*/
        return 1;
/*12312*/
    }
    if (strcmp(bigR, "00000") == 0)return 1;
/*12312*/
    return 0;
/*12312*/
}
int bintodec(const char* pbin)
{
    int ii = 0;
/*12312*/
    int result = 0;
/*12312*/
    while (pbin[ii] != 0)
    {
        result = result * 2 + (pbin[ii] - '0');
/*12312*/
        ii++;
/*12312*/
    }
    return result;
/*12312*/
}
char* strrev(char* s)
{
    /* h指向s的头部 */
    char* h = s;    
    char* t = s;
/*12312*/
    char ch;
/*12312*/
 
    /* t指向s的尾部 */
    while(*t++){};
/*12312*/
    t--;    /* 与t++抵消 */
    t--;    /* 回跳过结束符'\0' */
 
    /* 当h和t未重合时，交换它们所指向的字符 */
    while(h < t)
    {
        ch = *h;
/*12312*/
        *h++ = *t;    /* h向尾部移动 */
        *t-- = ch;    /* t向头部移动 */
    }
 
    return(s);
/*12312*/
}
int checkx0(command* input, int rdcheck, int rs1check, int rs2check)
{
    int result = 1;
/*12312*/
    if (rdcheck && strcmp(input->rd, "00000") == 0)result = 0;
/*12312*/
    if (rs1check && strcmp(input->rs1, "00000") == 0)result = 0;
/*12312*/
    if (rs2check && strcmp(input->rs2, "00000") == 0)result = 0;
/*12312*/
    return result;
/*12312*/
}
